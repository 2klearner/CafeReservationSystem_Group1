export class User{
    id:number=0;
    name:string='';
    email:string='';
    mobile:string='';
    address:string='';
    username:string='';
    password:string='';
    active:boolean=false;
}