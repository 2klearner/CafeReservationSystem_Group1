export class Admin {
    id: number | undefined;
    name: string | undefined;
    email: string | undefined;
    mobile: string | undefined;
    address: string | undefined;
    username: string | undefined;
    password: string | undefined;
  
}
  